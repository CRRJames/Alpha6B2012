/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.coderedrobotics;

import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj.PIDOutput;

/**
 * Drive system with two Jaguars driven in tank drive.
 *
 * @author Derek
 */
public class Drive implements PIDOutput {

    SafeJaguar rjag = null;
    SafeJaguar ljag = null;
    Gamepad gamepad;
    double lastSpeedLeft;
    double lastSpeedRight;

    /**
     * Drive system with two Jaguars driven in tank drive.
     *
     * @param Integer l is the port of the left Jaguar.
     * @param Integer r is the port of the right Jaguar.
     * @author Derek
     */
    public Drive(int l, int r, Gamepad g) {
        rjag = new SafeJaguar(r);
        ljag = new SafeJaguar(l);

        lastSpeedLeft = 0;
        lastSpeedRight = 0;

    }

    /**
     * Sets the speed of the left drive motor
     *
     * @param speed
     */
    public void setLeft(double speed) {
        double acc = speed - lastSpeedLeft;
        if (acc < -0.1) {
            acc = -0.1;
        }
        lastSpeedLeft = lastSpeedLeft + acc;
        ljag.set(-speed);
    }

    /**
     * Sets the speed of the right drive motor.
     *
     * @param speed
     */
    public void setRight(double speed) {
        double acc = speed - lastSpeedRight;
        if (acc > 0.1) {
            acc = 0.1;
        }
        lastSpeedRight = lastSpeedRight + acc;
        rjag.set(speed);
    }

    public void pidWrite(double output) {
//        if (Math.abs(output) < 0.2) {
//            if (output < 0) {
//                output = -0.2;
//            } else {
//                output = 0.2;
//            }
//        }
//        setRight(output);
//        setLeft(-output);
//        System.out.println("Drive pidWrite: " + output);
//        try {
//            Thread.sleep((long) (DriverStation.getInstance().getAnalogIn(2) * 100));
//        } catch (InterruptedException ex) {
//            ex.printStackTrace();
//        }
//        setRight(0);
//        setLeft(0);
    }
}
